package org.arle.proyectorolesauth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoRolesAuthApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProyectoRolesAuthApplication.class, args);
    }

}
